var functioncounter = 0;
var HowManyTimeFuncWillRun;
var dataAvailable = "No";
var DoesThisUserHasAds = "No";
var AmIOnline = "DontKnow";
firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      // User is signed in.
   
      isLoggedIn= "Yes";
  

      
      // ...
    } else {
      // User is signed out.
      // ...
      isLoggedIn= "No";
 

      
    }
  });


  var connectedRef = firebase.database().ref(".info/connected");
connectedRef.on("value", function(snap) {
  if (snap.val() === true) {
if(dataAvailable != "YES"){
    showUserADdata()}
    
    AmIOnline = "YES";
  } else {
    console.log("Offline")
    AmIOnline = "NO";

  
    
  }
});


function showUserADdata(){
    HasAdLoaded= "Yes";
    

firebase.database().ref(`TradeNow`).on('child_added',function(data2){
    
    //console.log(functioncounter+"/"+data2.numChildren())



    data2.forEach(data => {

    //  console.log(data.val())
        
  firebase.database().ref(`USERDETAILS/${data2.child("PostedBy").val()}`).once('value',function(userdata){
    dataAvailable = "YES"




  
  

        //console.log(data.child("Description").val())
        //console.log("lastloop: "+data.numChildren())



//data3.forEach(data => {
    
    

        document.getElementById("LoadingAds").className= "animated zoomOut"
        DoesThisUserHasAds = "Yes"
    

        $("#FakeAd").fadeOut('slow',function(){
    
     
        document.getElementById("mainbody").style="animation: unblur 1000ms ease-in-out; filter:blur(0px); pointer-events: auto;"




        if(data.child("Description").val().length >= 65){

    
            Description =  data.child("Description").val().replace(/&lt;br&gt;/g," ").slice(0,65)+'........';
         
            
         }else if(data.child("Description").val().length <= 65){
         
             Description = data.child("Description").val().replace(/&lt;br&gt;/g," ");
         };
         
         if(data.child("product").val().length >= 15){
         
         NameOfItem =  data.child("product").val().slice(0,15)+'....';
         
         //console.log("Name:- "+ data.child("product").val() +", length: "+NameOfItem.length+" condition:  " +(NameOfItem.length > 15))
         }else if(data.child("product").val().length <= 15){
         
             
         
             NameOfItem = data.child("product").val();
             
         };
          var PriceOfThis  = data.child("Price").val() 

    if(PriceOfThis.length > 10){

        PriceOfThis = data.child("Price").val().slice(0,8)+"...";
    }

    else if(PriceOfThis < 10 ){

        PriceOfThis  = data.child("Price").val()
    };
    
         
             if(isLoggedIn == "Yes"){
                 showadfunc = `showthisad('${data.key}','${data.child("PostedBy").val()}', '${data.child("category").val()}'); `
             }
             else if(isLoggedIn != "Yes"){
         
         
                 var AdDes  = data.child("Description").val()
                 var AdName = data.child("product").val() 
                 var AdTime  = data.child("PostTime").val() +', '+data.child("PostDate").val(); 
                 var AdCat  = data.child("category").val() 
                 var AdOwner  = data.child("PostedBy").val() 
                 var AdPrice  = data.child("Price").val() 
                 var AdModel  = data.child("Model").val() 
                 var AdYEar  = data.child("Year").val() 
                 var AdPic  = data.child("img1").val() 
         
         
                 showadfunc = "showofflinead("+'`'+AdTime+'`,`'+AdName+'`,`'+AdDes+'`,`'+AdCat+'`,`'+AdOwner+'`,`'+AdPrice+'`,`'+AdModel+'`,`'+AdYEar+'`,`'+AdPic+'`,`'+data.key+'`'+") ";

                 
             };
         
             
             

             //console.log(data.val())
             document.getElementById("mainbody").innerHTML += `<!-- Card --> <div description="${data.child("Year").val()+" "+data.child("Model").val()+" "+data.child("product").val()+" "+ data.child("Description").val().replace(/<(.|\n)*?>/g, '')}" removed="${data.key}" class="card mainbodycard animated fadeIn" > <div class="view overlay cardimg" onclick="BigPicture({ el: this, imgSrc: '${data.child("img1").val()}' })" > <img    class="card-img-top cardimg" src="${data.child("img1").val()}" alt="Card image cap"> <a> <div class="mask rgba-white-slight"></div> </a> </div> <a class="btn-floating btn-action ml-auto mr-4 mdb-color lighten-3"><i style="font-size: 35px;
             margin-left: -2px !important;" onclick="${showadfunc}" class="fa fa-eye pl-1"></i></a> <div class="card-body"> <h4 title="${data.child("product").val()}" class="card-title"> ${NameOfItem} </h4> <hr><p class="card-text TheDescription" data-animation="true" data-toggle="tooltip" data-html="true" data-trigger="click" title="${data.child("Description").val()}"> ${Description.replace(/<(.|\n)*?>/g, '')} </p><p class="cardviewPrice"  title="${'Rs. '+data.child("Price").val()}"> Rs ${PriceOfThis} </p> </div> <!-- Card footer --> <div class="rounded-bottom mdb-color lighten-3 text-center pt-3"> <ul class="list-unstyled list-inline font-small"> <li class="list-inline-item pr-2 white-text"><i class="fa fa-clock-o pr-1"></i>  ${data.child("PostTime").val()+', '+data.child("PostDate").val()} </li> </ul> </div> </div> <!-- Card -->`
         






        })



    

   

//});


    })
});//ForEach Ends



})






}