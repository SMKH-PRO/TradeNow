var loggedinornot =  "DontKnow";

firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      // User is signed in.
      loggedinornot = "Yes"

      // ...
    } else {
      // User is signed out.
      // ...
      loggedinornot= "Not"
    }

  });







  function showadfromlink(){

    if(loggedinornot !=  "DontKnow"){

      //  console.log("DontKnow")

  if(window.location.hash){

    
    


        

        




firebase.database().ref(`TradeNow`).once('child_added',function(data2){
 //console.log(data2.val())




   if(data2.hasChild(window.location.hash.replace(/\#/g,''))){
    if(loggedinornot == "Yes"){  //Checking if user is logged in or not?


data2.forEach(data => {
    




    if(data.key == window.location.hash.replace(/\#/g,'') ){



       /* firebase.database().ref(`TradeNow/${data.child('category').val()}/${window.location.hash.replace(/\#/g,'')}`).once('value',function(){})*/

    AdPic1= document.getElementById("productpic1");
    AdPic2= document.getElementById("productpic2");
    AdPic3= document.getElementById("productpic3");
    
        
    
        firebase.database().ref(`USERDETAILS/${data.child("PostedBy").val()}`).once('value',function(AdOwnerData){
           document.getElementById("addetailsusername").innerHTML =  AdOwnerData.child('FirstName').val();
           document.getElementById("addetailsuserimg").src =  AdOwnerData.child('ProfilePic').val();
           document.getElementById("bigimageofthisaduser").addEventListener('click',function(){ BigPicture({ el: this, imgSrc: AdOwnerData.child('ProfilePic').val()})});
           if(data.child("PostedBy").val() === firebase.auth().currentUser.uid){
            $("#ChatNowBtn").fadeOut();
        document.getElementById("EditAd").setAttribute('onclick', "updatethisad('"+data.key+"','"+data.child("category").val()+"')");
            
      
      
      
      
            $("#EditAd").fadeIn();
      
      
            $("#DeleteAd").fadeIn();
            
       document.getElementById("DeleteAd").setAttribute('onclick',"deletethiad('"+data.child("category").val()+"','"+data.key+"')");
             }
      
             else{
              $("#DeleteAd").fadeOut();
              $("#EditAd").fadeOut();
              $("#ChatNowBtn").fadeIn();
              document.getElementById("ChatNowBtn").href =  'CHAT/#'+data.child("PostedBy").val();
             }
    
    
    
    
           
    //Here ad data calling:
            firebase.database().ref(`TradeNow/${data.child("category").val()}/${window.location.hash.replace(/\#/g,'')}`).once('value',function(AdData){
                
                document.getElementById("adLink").value = window.location.origin+window.location.pathname+"#"+AdData.key;
    
                document.getElementById("shareadbtn").addEventListener('click',function(){  copylink() })
    
    
    
    
    document.getElementById("addetailtime").innerHTML=  AdData.child("PostTime").val()+", "+AdData.child('PostDate').val()
    
    document.getElementById("addetailsproductname").innerHTML = AdData.child('product').val()
    
    document.getElementById("addetailmodel").innerHTML = AdData.child('Model').val();
    document.getElementById("addetailyear").innerHTML = AdData.child('Year').val();
    document.getElementById("addetailcategory").innerHTML = AdData.child('category').val();
    
    document.getElementById("addetailprice").innerHTML = AdData.child('Price').val();
    document.getElementById("addetailsdescription").innerHTML = AdData.child('Description').val();
    //SET SRC 
    AdPic1.src= AdData.child("img1").val();
    AdPic2.src= AdData.child("img2").val();
    AdPic3.src= AdData.child("img3").val();
    //SET BIG PICTURE ON CLICK 
    AdPic1.addEventListener('click',function(){BigPicture({ el: this, imgSrc: AdData.child("img1").val() })});
    AdPic2.addEventListener('click',function(){BigPicture({ el: this, imgSrc: AdData.child("img2").val() })});
    AdPic3.addEventListener('click',function(){BigPicture({ el: this, imgSrc: AdData.child("img3").val() })});
    //SET ICONS/INDICATORS
    document.getElementById("productpic1icon").src= AdData.child("img1").val();
    document.getElementById("productpic2icon").src= AdData.child("img2").val();
    document.getElementById("productpic3icon").src= AdData.child("img3").val();
    
            })//ad data calling ends here
    
        })//owner data calling ends here
    
    
    
    
    
    
    $('#theparentofalldom').fadeOut(100,function(){
        $('#ThisAdInfo').modal({backdrop: 'static', keyboard: false})
    
    })
    



}



});





}// If condition for login check ends here, Else Starts below
else{

    //Show this messsage if user is not logged in..

firebase.database().ref(`TradeNow`).once('value',function(data2){



    data2.forEach(data => {
        
  

if(data.hasChild(window.location.hash.replace(/\#/g,''))){


   var AdDes  = data.child(window.location.hash.replace(/\#/g,'')).child("Description").val() 
   var AdName = data.child(window.location.hash.replace(/\#/g,'')).child("product").val() 
   var AdTime  = data.child(window.location.hash.replace(/\#/g,'')).child("PostTime").val() +', '+data.child(window.location.hash.replace(/\#/g,'')).child("PostDate").val(); 
   var AdCat  = data.child(window.location.hash.replace(/\#/g,'')).child("category").val() 
   var AdOwner  = data.child(window.location.hash.replace(/\#/g,'')).child("PostedBy").val() 
   var AdPrice  = data.child(window.location.hash.replace(/\#/g,'')).child("Price").val() 
   var AdModel  = data.child(window.location.hash.replace(/\#/g,'')).child("Model").val() 
   var AdYEar  = data.child(window.location.hash.replace(/\#/g,'')).child("Year").val() 
   var AdPic  = data.child(window.location.hash.replace(/\#/g,'')).child("img1").val() 


    showofflinead(AdTime,AdName,AdDes,AdCat,AdOwner,AdPrice,AdModel,AdYEar,AdPic,window.location.hash.replace(/\#/g,''))



}else{

   Console.log("Ad Not Found, Wrong Ad Id")
}
});//ForEach Ends



})

}


}//Here the checking of hash id (ad id) ends..
else{

    console.log("Ad Not Found, Wrong Ad id")
   }


   
})






   
}

    }
    else{

        

        setTimeout(function(){showadfromlink()},500)
    }
  }
  
 setTimeout(function(){showadfromlink()},500) 