
        setInterval(function(){
          setTimeout(function(){
            
           

            $('[title]').tooltip();
        
        },100)},500)
          

var userid;
var searchboxOpen = "NO";
var HasAdLoaded = "NO";
var isLoggedIn= "No";

  window.onscroll = function() {fixnavbar()};
  var spacer = document.getElementById("spacer");
var header = document.getElementById("mynavbar");
var sticky = header.offsetTop;

function fixnavbar() {

  if(searchboxOpen == "NO"){
  if (window.pageYOffset > sticky) {
    header.classList.add("fixed-top");
    spacer.style="display:block;"
  } else {
    header.classList.remove("fixed-top");
    spacer.style="display:none;"
  }}
}


function getmoredetails(){
  var  LastName = document.getElementById("UserLastName")
   var FirstName = document.getElementById("UserFirstName")
   var fullname= FirstName.value +" "+LastName.value;


   if(FirstName.value.length <2){
shownotif("Warning!","Please Write Your First Name.","danger","2")
return false;
   }
   
  else if(FirstName.value.length >10){
       shownotif("Warning!","User First Name Must Not Exceed 10 Characters..!","danger","2")
       return false;
           }
else if(LastName.value.length <2){
shownotif("Warning!","Please Write Your Last Name.","danger","2")
return false;
   }
   
  else if(LastName.value.length >10){
       shownotif("Warning!","User Last Name Must Not Exceed 10 Characters..!","danger","2")
       return false;
           }
           
           

   else{
       firebase.database().ref(`USERDETAILS/${userid}`).on('value',(data)=>{

        var moredetails = {Name:fullname,FirstName:FirstName.value,LastName: LastName.value,ProfilePic:firebase.auth().currentUser.photoURL,RegisteredWithArea: usercity+", "+usercountry ,LastLoginArea: usercity+", "+usercountry,RegisteredWithIP: userip,LastIP:userip,RegisteredWithISP: isp,LastISP: isp, Email:firebase.auth().currentUser.email}


       firebase.database().ref(`/USERDETAILS/${firebase.auth().currentUser.uid}`).set(moredetails).then(()=>{
           $("#modalmoreinfo").modal("hide");



          // setTimeout(function(){location.reload()},500)
                  })//then ends here

       })


       firebase.auth().currentUser.updateProfile({
           displayName:  FirstName.value,
           photoURL: "/defaultuser.png"
         }).then(function() {
           // console.log(user.displayName)
     
     
       console.log("Name Updated..!")
         }).catch(function(error) {
           // An error happened.
           shownotif("Error",error,"danger","1")
         });
             

   }


}


           
           
           
           function setIP(){
            firebase.database().ref(`/USERDETAILS/${userid}`).once('value',(data)=>{
            
            if(data.hasChild("LastIP") != true || data.child(useripstring).val() != useripstring){
        
              firebase.database().ref(`/USERDETAILS/${userid}`).update({LastIP:userip,LastISP:isp,LastLoginArea:usercity+", "+usercountry})

        
        } 
        
            })
        
        }
           
           function checkforuserdetails(){
            setIP()
            
        
        
        
            firebase.database().ref(`/USERDETAILS/${firebase.auth().currentUser.uid}`).on('value',(data)=>{
        
                if(data.hasChild("FirstName") == false || data.hasChild("Name") == false || data.child("Name").val() === null ||data.child("Name").val() == "null"){
                    $("#modalmoreinfo").modal({backdrop: 'static', keyboard: false})  
        
                }

        else{
        
            $("#modalmoreinfo").modal('hide')  
        
        }
                
        
        
            
            })
        }
        
         
        function getmoredetailskeydown() {
          if (event.keyCode == 13) { 
              getmoredetails()
                    }
                 }
        document.getElementById("UserFirstName").addEventListener("keydown",getmoredetailskeydown)
        document.getElementById("UserLastName").addEventListener("keydown",getmoredetailskeydown)
        document.getElementById("senddetails-btn").addEventListener("click",getmoredetails)
       
                   

        firebase.auth().onAuthStateChanged(function(user) {
          if (user) {
            // User is signed in.
            isLoggedIn= "Yes";
            $(".UserMyOwnAds").show();
            $(".UserMyOwnAds").attr("href",  "/userads.html#"+user.uid);
         

if(window.location.pathname != "/publish.html"){document.getElementById("loginbtn").style="display:none;"}

            
document.getElementById("navbaruserimgavatar").src = user.photoURL;
document.getElementById("navbar-name").innerHTML = user.displayName;

document.getElementById("nav-userdata").style="display: flex;"

if(isLoggedIn == "Yes"){
  $("#nav-userdata").show()
  }
            
            userid = firebase.auth().currentUser.uid
            var displayName = user.displayName;
          firebase.database().ref(`USERDETAILS/${firebase.auth().currentUser.uid}`).on('value',function(data){
          
          if(data.child("ProfilePic").val() != firebase.auth().currentUser.photoURL){
              firebase.database().ref(`USERDETAILS/${firebase.auth().currentUser.uid}`).update({
                  
                  ProfilePic: firebase.auth().currentUser.photoURL
              })
              
          }
      })
      checkforuserdetails()
      $('.HideWhenNotLoggedIn').show()
            // ...
          } else {
            // User is signed out.
            // ...

            
    setTimeout(function(){if(isLoggedIn !="Yes"){$("#nav-userdata").hide()}},500)
    
    setTimeout(function(){$("#nav-userdata").hide()},500)

            $('.HideWhenNotLoggedIn').hide()
            $(".UserMyOwnAds").hide()
            isLoggedIn= "No";
            
            if(window.location.pathname != "publish.html"){
            document.getElementById("loginbtn").style="display:inline;"
            }
            document.getElementById("nav-userdata").style="display: none;"
            $('#nav-userdata').hide();
          }
        });





        function logout(){

          firebase.auth().signOut().then(function(){

            location.reload();
          })
        }

        document.getElementById("LogOutBtn").addEventListener('click',logout)



        var connectedRef = firebase.database().ref(".info/connected");
connectedRef.on("value", function(snap) {
  if (snap.val() === true) {
    setTimeout(function(){$('[title]').tooltip('hide');},500)
  } else {
    setTimeout(function(){$('[title]').tooltip('hide');},500)
  }
});

        

$("#FooterInstructions").click(function(){
  $("#InstructionsForUser").modal("show");
})







firebase.messaging().onMessage(function(payload) {
 

   // alert(payload.notification.title);
//console.log(payload)



   var notifsound = new Audio('/notification.m4a');
notifsound.play()

  pushnotif(payload.notification.title.substring(12),payload.notification.body,"7","/CHAT/#"+payload.data["gcm.notification.senderID"],payload.notification.icon)
  
  //function pushnotif(title,msg,type,time,url,imglink)
  
  
  //console.log(payload.data["gcm.notification.senderID"])
 
  // ...
});
